
=================================================
 API Reference — Stars and other distant objects
=================================================

.. testsetup::

   from pprint import pprint
   from skyfield.api import Star, Angle

.. currentmodule:: skyfield.starlib

.. autoclass:: Star
   :members:
